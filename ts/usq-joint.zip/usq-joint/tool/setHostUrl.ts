import config from 'config';

const usqHost = config.get<string>('usqhost');

export function urlSetUsqHost(url:string):string {
    return url.replace('://usqhost/', '://'+usqHost+'/');
}

const unitxHost = config.get<string>('unitxhost');
export function urlSetUnitxHost(url:string):string {
    return url.replace('://unitxhost/', '://'+unitxHost+'/');
}

