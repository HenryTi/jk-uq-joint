import {default as queue} from './queue';

export const tableDefs = [
    ...queue
];
