import {default as sys} from './sys';
import {default as queue} from './queue';

export const procDefs = [
    ...sys,
    ...queue
];
